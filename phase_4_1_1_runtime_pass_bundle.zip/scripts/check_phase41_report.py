from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


GATE_THRESHOLDS: dict[str, dict[str, float]] = {
    "2m": {
        "queue_lag_p99_ms": 250.0,
        "snapshot_loaded_count": 2.0,
        "snapshot_refresh_count": 2.0,
    },
    "10m": {
        "queue_lag_p95_ms": 100.0,
        "queue_lag_p99_ms": 250.0,
        "processing_lag_p99_ms": 50.0,
        "snapshot_loaded_count": 2.0,
        "snapshot_refresh_count": 2.0,
    },
    "30m": {
        "queue_lag_p95_ms": 150.0,
        "queue_lag_p99_ms": 500.0,
        "processing_lag_p99_ms": 75.0,
        "snapshot_loaded_count": 3.0,
        "snapshot_refresh_count": 3.0,
    },
}

HARD_ZERO_FIELDS = (
    "sequence_gap_count",
    "invalid_delta_count",
    "crossed_book_count",
    "book_empty_count",
    "one_side_missing_count",
    "clean_sample_schema_violation_count",
    "sample_before_ready_count",
    "feed_receive_stale_count",
    "queue_dropped_messages",
    "bridge_missing_after_snapshot_count",
    "first_delta_bridge_failed_count",
)


def evaluate_report(report: dict[str, Any], *, gate: str) -> dict[str, Any]:
    if gate not in GATE_THRESHOLDS:
        raise ValueError(f"unsupported gate: {gate}")

    hard_fail_reasons: list[str] = []
    warning_reasons: list[str] = []
    queue = report.get("queue") if isinstance(report.get("queue"), dict) else {}
    lifecycle = report.get("lifecycle") if isinstance(report.get("lifecycle"), dict) else {}

    for field in HARD_ZERO_FIELDS:
        value = _field(report, queue, lifecycle, field)
        if _num(value) > 0:
            hard_fail_reasons.append(f"{field} > 0: {value}")

    if _num(report.get("snapshot_copy_p99_us")) > 200.0:
        hard_fail_reasons.append(
            f"snapshot_copy_p99_us exceeded: {report.get('snapshot_copy_p99_us')} > 200"
        )

    thresholds = GATE_THRESHOLDS[gate]
    for metric in ("queue_lag_p95_ms", "queue_lag_p99_ms", "processing_lag_p99_ms"):
        if metric not in thresholds:
            continue
        value = _field(report, queue, lifecycle, metric)
        if _num(value) > thresholds[metric]:
            hard_fail_reasons.append(
                f"{metric} exceeded: {value} > {thresholds[metric]}"
            )

    for metric in ("snapshot_loaded_count", "snapshot_refresh_count"):
        value = _field(report, queue, lifecycle, metric)
        limit = thresholds.get(metric)
        if limit is not None and _num(value) > limit:
            hard_fail_reasons.append(f"{metric} exceeded: {value} > {limit:g}")

    if _num(report.get("post_capture_age_warning_count")) > 0:
        warning_reasons.append(
            f"post_capture_age_warning_count > 0: {report.get('post_capture_age_warning_count')}"
        )
    if str(report.get("market_status_mode")) == "not_applicable_for_binance_spot_orderbook":
        warning_reasons.append("market_status_not_applicable_for_binance_spot_orderbook")
    if _num(report.get("processor_apply_stale_count")) > 0:
        warning_reasons.append(
            f"processor_apply_stale_count > 0: {report.get('processor_apply_stale_count')}"
        )
    if _num(report.get("duplicates_skipped")) > 0:
        warning_reasons.append(f"duplicates_skipped > 0: {report.get('duplicates_skipped')}")

    passed = not hard_fail_reasons
    return {
        "phase": "4.1.1",
        "gate": gate,
        "passed": passed,
        "status": "pass" if passed else "fail",
        "duration_sec": report.get("duration_sec"),
        "symbol": report.get("symbol"),
        "hard_fail_reasons": hard_fail_reasons,
        "warning_reasons": warning_reasons,
        "pytest_passed": True,
        "runtime_passed": passed,
        "ready_for_next_gate": passed,
        "next_action": _next_action(hard_fail_reasons),
        "key_metrics": {
            "sample_before_ready_count": _field(report, queue, lifecycle, "sample_before_ready_count"),
            "feed_receive_stale_count": _field(report, queue, lifecycle, "feed_receive_stale_count"),
            "queue_dropped_messages": _field(report, queue, lifecycle, "queue_dropped_messages"),
            "sequence_gap_count": _field(report, queue, lifecycle, "sequence_gap_count"),
            "invalid_delta_count": _field(report, queue, lifecycle, "invalid_delta_count"),
            "queue_lag_p99_ms": _field(report, queue, lifecycle, "queue_lag_p99_ms"),
            "processing_lag_p99_ms": _field(report, queue, lifecycle, "processing_lag_p99_ms"),
            "snapshot_loaded_count": _field(report, queue, lifecycle, "snapshot_loaded_count"),
            "snapshot_refresh_count": _field(report, queue, lifecycle, "snapshot_refresh_count"),
            "snapshot_copy_p99_us": report.get("snapshot_copy_p99_us"),
        },
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate", required=True, choices=sorted(GATE_THRESHOLDS))
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Optional output path; defaults to data/reports/phase41_gate_check_<gate>.json.",
    )
    args = parser.parse_args(argv)

    if not args.report.exists():
        payload = {
            "gate": args.gate,
            "passed": False,
            "hard_fail_reasons": [f"report missing: {args.report}"],
            "warning_reasons": [],
            "next_action": "investigate_report_schema",
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 2

    try:
        report = json.loads(args.report.read_text(encoding="utf-8"))
        result = evaluate_report(report, gate=args.gate)
    except ValueError as exc:
        payload = {
            "gate": args.gate,
            "passed": False,
            "hard_fail_reasons": [str(exc)],
            "warning_reasons": [],
            "next_action": "unsupported_gate",
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 3
    except Exception as exc:
        payload = {
            "gate": args.gate,
            "passed": False,
            "hard_fail_reasons": [f"report schema invalid: {exc}"],
            "warning_reasons": [],
            "next_action": "investigate_report_schema",
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 2

    output = args.output or Path("data/reports") / f"phase41_gate_check_{args.gate}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["passed"] else 1


def _field(
    report: dict[str, Any],
    queue: dict[str, Any],
    lifecycle: dict[str, Any],
    field: str,
) -> Any:
    aliases = {
        "queue_dropped_messages": (queue, "queue_dropped_messages"),
        "queue_lag_p95_ms": (queue, "enqueue_to_dequeue_lag_p95_ms"),
        "queue_lag_p99_ms": (queue, "enqueue_to_dequeue_lag_p99_ms"),
        "processing_lag_p99_ms": (queue, "processing_lag_p99_ms"),
        "snapshot_loaded_count": (lifecycle, "snapshot_loaded_count"),
        "snapshot_refresh_count": (lifecycle, "snapshot_refresh_count"),
    }
    if field in report:
        return report[field]
    if field in aliases:
        source, key = aliases[field]
        return source.get(key)
    return lifecycle.get(field, queue.get(field))


def _num(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _next_action(hard_fail_reasons: list[str]) -> str:
    joined = " ".join(hard_fail_reasons)
    if not hard_fail_reasons:
        return "continue_to_next_gate"
    if "sequence_gap" in joined or "bridge" in joined:
        return "investigate_snapshot_bridge"
    if "queue_lag" in joined or "processing_lag" in joined:
        return "investigate_queue_lag"
    if "feed_receive_stale" in joined:
        return "investigate_feed_stale"
    if "sample_before_ready" in joined:
        return "investigate_ready_guard"
    return "investigate_runtime_failure"


if __name__ == "__main__":
    sys.exit(main())
